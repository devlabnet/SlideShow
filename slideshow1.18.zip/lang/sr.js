﻿/*
Copyright (c) 2003-2013, Cricri042. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
Targeted for "ad-gallery" JavaScript : http://adgallery.codeplex.com/
And "Fancybox" : http://fancyapps.com/fancybox/
*/
CKEDITOR.plugins.setLang( 'slideshow', 'sr', {
	toolbar	: 'Слајд шоу',
	dialogTitle : 'Слајд шоу подешавања',
	fakeObject : 'Слајд шоу',
	imgList : 'Слика',
	imgAdd : 'додај Слику',
	imgTitle : 'Наслов',
	imgDelete : 'Обриши',
	imgEdit : 'Уреди',
	previewMode : 'Преглед',
	imgDesc : 'Краћи опис',
    validModif : 'сачувате промене',
	editSlideShow : 'УредиСлајд шоу',
	picturesList : "Листа Слика :",
	insertSlideShow : 'Инсертуј Слајд шоу',
	showThumbs : 'Прикажи умањене',
	showTitle : 'Прикажи наслов',
	showControls : "Прикажи Старт/Стоп",
	labelStart : "Старт",
	labelStop : "Стоп",
	arrowUp : "\u2191",
	arrowDown : "\u2193",
	displayTime : 'Покаж. Време (Сек.)',
	transitionTime : 'Пр. Време (мСек.)',
	autoStart : 'АутоСтарт',
	pictHeight : 'Висина (пкс)',
	pictWidth : 'ширина  (пкс)',
	openOnClick : 'На клик отвори',
	transition : 'Тип транзиције',
	tr1 : 'Ниједна',
	tr2 : 'Промени вел',
	tr3 : 'Слајд вертикални',
	tr4 : 'Слајд хоризонтални',
	tr5 : 'Фаде',
});
